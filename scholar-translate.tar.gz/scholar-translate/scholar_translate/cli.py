"""Command-line entry point.

  python -m scholar_translate.cli search "graphene supercapacitor" --limit 3
  python -m scholar_translate.cli files input/
  python -m scholar_translate.cli text "Climate change is a pressing issue."
"""

import argparse
import json
import sys
from pathlib import Path

from . import TARGETS
from .sources import read_dir, read_file, search_openalex
from .translate import translate_all

OUTPUT = Path("output")


def _slug(text: str, n: int = 60) -> str:
    keep = [c if c.isalnum() else "-" for c in text.lower()]
    return "".join(keep).strip("-")[:n] or "untitled"


def _write(name: str, source_text: str, translations: dict[str, str]) -> Path:
    OUTPUT.mkdir(exist_ok=True)
    payload = {"name": name, "source": source_text, "translations": translations}

    json_path = OUTPUT / f"{name}.json"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                         encoding="utf-8")

    for lang, text in translations.items():
        (OUTPUT / f"{name}.{lang}.txt").write_text(text, encoding="utf-8")

    return json_path


def _run(name: str, text: str, languages: list[str]) -> None:
    print(f"\n-- {name} ({len(text)} chars)", flush=True)
    translations = translate_all(text, languages)
    path = _write(_slug(name), text, translations)
    for lang, out in translations.items():
        preview = out[:120].replace("\n", " ")
        print(f"   {lang:8} {preview}{'...' if len(out) > 120 else ''}")
    print(f"   written -> {path}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="scholar-translate")
    parser.add_argument("--languages", default=",".join(TARGETS),
                        help=f"comma-separated subset of {list(TARGETS)}")
    parser.add_argument("--mailto", help="your email, for the OpenAlex polite pool")

    sub = parser.add_subparsers(dest="command", required=True)

    s = sub.add_parser("search", help="search OpenAlex and translate abstracts")
    s.add_argument("query")
    s.add_argument("--limit", type=int, default=5)

    f = sub.add_parser("files", help="translate local .pdf/.txt/.md files")
    f.add_argument("path", help="a file or a directory")

    t = sub.add_parser("text", help="translate a string")
    t.add_argument("value")

    args = parser.parse_args(argv)
    args.languages = [l.strip().lower() for l in args.languages.split(",") if l.strip()]

    if args.command == "search":
        works = search_openalex(args.query, args.limit, args.mailto)
        if not works:
            print("No results.")
            return 1
        for work in works:
            body = work["abstract"] or work["title"]
            _run(f"{work['id']}-{work['title']}", f"{work['title']}\n\n{body}",
                 args.languages)

    elif args.command == "files":
        path = Path(args.path)
        if not path.exists():
            print(f"No such path: {path}", file=sys.stderr)
            return 1
        items = read_dir(path) if path.is_dir() else [(path.stem, read_file(path))]
        if not items:
            print(f"No .pdf/.txt/.md files found in {path}")
            return 1
        for name, text in items:
            _run(name, text, args.languages)

    else:
        _run("text", args.value, args.languages)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
