"""Sarvam client construction. Key comes from the environment only."""

import os

from dotenv import load_dotenv
from sarvamai import SarvamAI

_client = None


def get_client() -> SarvamAI:
    """Return a cached SarvamAI client, or raise if the key is missing."""
    global _client
    if _client is None:
        load_dotenv()
        key = os.getenv("SARVAM_API_KEY")
        if not key:
            raise RuntimeError(
                "SARVAM_API_KEY is not set. Copy .env.example to .env and add your key."
            )
        _client = SarvamAI(api_subscription_key=key)
    return _client
