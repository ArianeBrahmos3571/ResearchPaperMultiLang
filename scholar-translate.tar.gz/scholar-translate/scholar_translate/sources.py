"""Where the text to translate comes from.

Google Scholar has no public API and its terms forbid automated scraping, so
this module does not touch it. Two supported inputs:

  openalex  - free scholarly metadata API (no key). Covers much the same corpus
              as Scholar and returns titles + abstracts you can translate.
  files     - local .pdf / .txt / .md files you supply yourself, e.g. papers you
              downloaded from Scholar by hand.
"""

from pathlib import Path

import requests

OPENALEX = "https://api.openalex.org/works"


def search_openalex(query: str, limit: int = 5, mailto: str | None = None) -> list[dict]:
    """Search OpenAlex. Returns [{id, title, year, abstract, url}, ...]."""
    params = {
        "search": query,
        "per-page": min(limit, 50),
        "select": "id,title,publication_year,abstract_inverted_index,doi",
    }
    if mailto:
        params["mailto"] = mailto           # polite pool, faster rate limits

    resp = requests.get(OPENALEX, params=params, timeout=30)
    resp.raise_for_status()

    works = []
    for item in resp.json().get("results", []):
        works.append({
            "id": (item.get("id") or "").rsplit("/", 1)[-1],
            "title": item.get("title") or "untitled",
            "year": item.get("publication_year"),
            "abstract": _rebuild_abstract(item.get("abstract_inverted_index")),
            "url": item.get("doi") or item.get("id"),
        })
    return works


def _rebuild_abstract(inverted: dict | None) -> str:
    """OpenAlex stores abstracts as {word: [positions]}. Put them back in order."""
    if not inverted:
        return ""
    positions: list[tuple[int, str]] = []
    for word, idxs in inverted.items():
        positions.extend((i, word) for i in idxs)
    return " ".join(word for _, word in sorted(positions))


def read_file(path: str | Path) -> str:
    """Extract plain text from a .pdf, .txt or .md file."""
    path = Path(path)
    if path.suffix.lower() == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        return "\n\n".join((page.extract_text() or "") for page in reader.pages).strip()
    return path.read_text(encoding="utf-8", errors="replace").strip()


def read_dir(directory: str | Path) -> list[tuple[str, str]]:
    """Read every supported file in a directory. Returns [(name, text), ...]."""
    directory = Path(directory)
    out = []
    for path in sorted(directory.iterdir()):
        if path.suffix.lower() in {".pdf", ".txt", ".md"}:
            text = read_file(path)
            if text:
                out.append((path.stem, text))
    return out
