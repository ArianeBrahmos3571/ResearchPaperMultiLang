"""scholar_translate — translate scholarly text into Hindi, Marathi and Telugu."""

__all__ = ["TARGETS", "client", "translate", "sources"]

# BCP-47 codes Sarvam's translation API expects.
TARGETS = {
    "hindi": "hi-IN",
    "marathi": "mr-IN",
    "telugu": "te-IN",
}
