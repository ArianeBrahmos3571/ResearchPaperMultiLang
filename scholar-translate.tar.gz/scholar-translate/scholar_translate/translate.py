"""Translation pipeline.

Sarvam's translation API (`sarvam-translate:v1`) translates between English and
the Indian languages. It does not accept Chinese, Japanese, Korean, Russian,
etc. as a source. So for those we pivot: the chat model renders the text into
English first, then the translation API produces Hindi / Marathi / Telugu.
"""

import re
import time
import unicodedata

from sarvamai.core.api_error import ApiError

from . import TARGETS
from .client import get_client

# sarvam-translate:v1 accepts up to 2000 characters per request.
MAX_CHARS = 1800
CHAT_MODEL = "sarvam-105b-conversations"
TRANSLATE_MODEL = "sarvam-translate:v1"

# Scripts the translation API handles directly as a source.
_DIRECT_SCRIPTS = {"LATIN", "DEVANAGARI", "TELUGU", "BENGALI", "TAMIL",
                   "KANNADA", "MALAYALAM", "GUJARATI", "GURMUKHI", "ORIYA"}


def _script_of(ch: str) -> str:
    try:
        return unicodedata.name(ch).split()[0]
    except ValueError:
        return ""


def needs_english_pivot(text: str, threshold: float = 0.05) -> bool:
    """True if enough of the text is in a script the translate API won't take."""
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return False
    foreign = sum(1 for c in letters if _script_of(c) not in _DIRECT_SCRIPTS)
    return foreign / len(letters) > threshold


def chunk(text: str, limit: int = MAX_CHARS) -> list[str]:
    """Split text into <=limit pieces, breaking on paragraphs then sentences."""
    text = text.strip()
    if len(text) <= limit:
        return [text] if text else []

    pieces: list[str] = []
    for para in re.split(r"\n\s*\n", text):
        para = para.strip()
        if not para:
            continue
        if len(para) <= limit:
            pieces.append(para)
            continue
        buf = ""
        for sentence in re.split(r"(?<=[.!?।])\s+", para):
            while len(sentence) > limit:          # pathological single sentence
                if buf:
                    pieces.append(buf)
                    buf = ""
                pieces.append(sentence[:limit])
                sentence = sentence[limit:]
            if len(buf) + len(sentence) + 1 <= limit:
                buf = f"{buf} {sentence}".strip()
            else:
                if buf:
                    pieces.append(buf)
                buf = sentence
        if buf:
            pieces.append(buf)
    return pieces


def _retry(fn, attempts: int = 4):
    """Call fn with exponential backoff on rate limits / transient API errors."""
    for i in range(attempts):
        try:
            return fn()
        except ApiError as exc:
            retryable = exc.status_code in (408, 429, 500, 502, 503, 504)
            if not retryable or i == attempts - 1:
                raise
            time.sleep(2 ** i)


def to_english(text: str) -> str:
    """Render non-Indic, non-English text into English via the chat model."""
    client = get_client()
    out = []
    for piece in chunk(text, 4000):
        resp = _retry(lambda p=piece: client.chat.completions(
            model=CHAT_MODEL,
            messages=[
                {"role": "system", "content":
                 "You are an academic translator. Translate the user's text into "
                 "clear, faithful English. Preserve technical terminology, numbers "
                 "and citations exactly. Output only the translation."},
                {"role": "user", "content": p},
            ],
            temperature=0.2,
        ))
        out.append(resp.choices[0].message.content.strip())
    return "\n\n".join(out)


def translate(text: str, target: str, source: str = "en-IN") -> str:
    """Translate text into one target language code (e.g. 'hi-IN')."""
    client = get_client()
    out = []
    for piece in chunk(text):
        resp = _retry(lambda p=piece: client.text.translate(
            input=p,
            source_language_code=source,
            target_language_code=target,
            model=TRANSLATE_MODEL,
            mode="formal",
        ))
        out.append(resp.translated_text.strip())
    return "\n\n".join(out)


def translate_all(text: str, languages: list[str] | None = None) -> dict[str, str]:
    """Translate text into each requested language. Keys are language names."""
    languages = languages or list(TARGETS)

    if needs_english_pivot(text):
        text = to_english(text)

    results = {}
    for name in languages:
        code = TARGETS.get(name.lower())
        if not code:
            raise ValueError(f"Unsupported language: {name}. Pick from {list(TARGETS)}.")
        results[name.lower()] = translate(text, code)
    return results
