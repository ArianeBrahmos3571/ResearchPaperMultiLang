"""Minimal smoke test: one chat completion call against Sarvam AI.

Run:  python hello_sarvam.py
"""

import os
import sys

from dotenv import load_dotenv
from sarvamai import SarvamAI

load_dotenv()

api_key = os.getenv("SARVAM_API_KEY")
if not api_key:
    sys.exit("SARVAM_API_KEY is not set. Put it in .env (see .env.example).")

client = SarvamAI(api_subscription_key=api_key)

response = client.chat.completions(
    model="sarvam-105b-conversations",
    messages=[
        {"role": "user", "content": "In one sentence, what is Sarvam AI?"}
    ],
)

print(response.choices[0].message.content)
