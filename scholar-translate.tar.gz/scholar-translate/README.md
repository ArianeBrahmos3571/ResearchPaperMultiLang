# scholar-translate

Translates scholarly text — titles, abstracts, full papers — into **Hindi, Marathi and Telugu** using the [Sarvam AI](https://docs.sarvam.ai) APIs.

Source text can be in English, an Indian language, or a foreign script (Chinese, Japanese, Korean, Russian…). Sarvam's translation model only accepts English and Indian languages as a *source*, so anything else is first rendered into English by the `sarvam-105b-conversations` chat model and then translated. That pivot happens automatically.

## About Google Scholar

Google Scholar has **no public API**, and automated scraping of it violates its terms of service and gets your IP blocked quickly. This project does not scrape it. Instead:

- **`search`** queries [OpenAlex](https://openalex.org) — a free, open scholarly index (no API key) covering much of the same literature, returning titles and abstracts.
- **`files`** translates `.pdf`, `.txt` and `.md` files you supply yourself. Download whatever you like from Scholar by hand, drop it in `input/`, and run it.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env         # then put your key in it
```

`.env` holds one line:

```
SARVAM_API_KEY=your_key_here
```

Get a key at <https://dashboard.sarvam.ai>. `.env` is gitignored — the key is read from the environment and never written into source.

Check it works:

```bash
python hello_sarvam.py
```

## Usage

```bash
# Search OpenAlex and translate the abstracts
python -m scholar_translate.cli search "graphene supercapacitor" --limit 3

# Translate local papers
python -m scholar_translate.cli files input/

# A single file, or a single string
python -m scholar_translate.cli files input/paper.pdf
python -m scholar_translate.cli text "Climate change is a pressing global issue."

# Only some languages
python -m scholar_translate.cli --languages hindi,telugu files input/
```

Pass `--mailto you@example.com` on `search` to join OpenAlex's polite pool (faster, more generous rate limits).

### Output

For each item, `output/` gets:

```
output/<name>.json          # source text + all three translations
output/<name>.hindi.txt
output/<name>.marathi.txt
output/<name>.telugu.txt
```

## Layout

```
hello_sarvam.py              one API call, to verify the key works
scholar_translate/
  __init__.py                target language codes
  client.py                  builds the Sarvam client from $SARVAM_API_KEY
  translate.py               chunking, English pivot, retries
  sources.py                 OpenAlex search + PDF/text reading
  cli.py                     command line
input/                       put your own PDFs here
output/                      results land here
```

## Notes

- Text is chunked to 1800 characters per request, the limit for `sarvam-translate:v1`, splitting on paragraph then sentence boundaries.
- Rate limits and transient 5xx errors are retried with exponential backoff.
- Full PDFs are many chunks and therefore many API calls. Try one paper before a batch.
- PDF text extraction is only as good as the PDF. Scanned papers need OCR first; `pypdf` will return empty text for them.

## Models used

| Purpose | Model |
|---|---|
| Foreign-script → English pivot | `sarvam-105b-conversations` |
| English/Indic → Hindi, Marathi, Telugu | `sarvam-translate:v1` |
